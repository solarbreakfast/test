import { AudioState } from '../../types/audio';
import { AUDIO_CONSTRAINTS } from '../../constants';

export interface RandomConstraint {
  min: number;
  max: number;
  step: number;
}

export const getConstraintsForParam = (param: keyof AudioState): RandomConstraint => {
  return {
    min: AUDIO_CONSTRAINTS[param].min,
    max: AUDIO_CONSTRAINTS[param].max,
    step: AUDIO_CONSTRAINTS[param].step
  };
};