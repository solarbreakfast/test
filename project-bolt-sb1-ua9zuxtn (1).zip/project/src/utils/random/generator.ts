import { RandomConstraint } from './constraints';

export const generateRandomValue = (constraints: RandomConstraint): number => {
  const { min, max, step } = constraints;
  const steps = Math.floor((max - min) / step);
  return min + (Math.floor(Math.random() * steps) * step);
};