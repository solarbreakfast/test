import { AudioState } from '../../types/audio';
import { RandomConstraint } from './constraints';
import { generateRandomValue } from './generator';

export interface RandomParameters {
  tempo: number;
  pitch: number;
  frequency: number;
  noise: number;
  echo: number;
}

export function generateRandomParameters(constraints: Record<keyof AudioState, RandomConstraint>): RandomParameters {
  return {
    tempo: generateRandomValue(constraints.tempo),
    pitch: generateRandomValue(constraints.pitch),
    frequency: generateRandomValue(constraints.frequency),
    noise: generateRandomValue(constraints.noise),
    echo: generateRandomValue(constraints.echo)
  };
}