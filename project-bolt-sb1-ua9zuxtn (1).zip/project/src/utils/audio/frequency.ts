import { MUSICAL_FREQUENCIES } from '../../constants/frequencies';

export function calculateFrequencyPosition(freq: number, minFreq: number, maxFreq: number): number {
  return ((Math.log2(freq) - Math.log2(minFreq)) / (Math.log2(maxFreq) - Math.log2(minFreq))) * 100;
}

export function calculateFrequencyFromPosition(pos: number, minFreq: number, maxFreq: number): number {
  const freq = Math.pow(2, (pos / 100) * (Math.log2(maxFreq) - Math.log2(minFreq)) + Math.log2(minFreq));
  return Math.max(minFreq, Math.min(maxFreq, Math.round(freq)));
}

export function getNearestMusicalNote(frequency: number) {
  return MUSICAL_FREQUENCIES.reduce((prev, curr) => {
    return Math.abs(curr.freq - frequency) < Math.abs(prev.freq - frequency) ? curr : prev;
  });
}

export function calculateFrequencyQ(frequency: number, nearestNote: typeof MUSICAL_FREQUENCIES[0]) {
  const proximity = Math.abs(frequency - nearestNote.freq) / frequency;
  const baseQ = 1.0;
  const resonanceQ = 2.5;
  return baseQ + (1 - Math.min(proximity * 10, 1)) * (resonanceQ - baseQ);
}