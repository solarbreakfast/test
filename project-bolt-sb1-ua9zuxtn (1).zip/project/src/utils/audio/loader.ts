import { AudioLoadingOptions } from '../types';

export async function loadAudioFile(file: File, options: AudioLoadingOptions = {}): Promise<AudioBuffer> {
  // Validate file type
  const supportedTypes = ['audio/wav', 'audio/mp3', 'audio/aac', 'audio/mpeg'];
  if (!supportedTypes.includes(file.type)) {
    throw new Error(`Unsupported file type: ${file.type}`);
  }

  try {
    // Create audio context with high-quality settings
    const audioContext = new (window.AudioContext || window.webkitAudioContext)({
      // Use the file's original sample rate if available, otherwise use high quality default
      sampleRate: options.preserveOriginal ? undefined : (options.sampleRate || 48000),
      latencyHint: 'playback'
    });

    // Read file as ArrayBuffer
    const arrayBuffer = await file.arrayBuffer();

    // Decode audio data with preserved settings
    const audioBuffer = await audioContext.decodeAudioData(arrayBuffer);

    // Validate audio data
    validateAudioBuffer(audioBuffer);

    return audioBuffer;
  } catch (error) {
    console.error('Error loading audio file:', error);
    throw error;
  }
}

function validateAudioBuffer(buffer: AudioBuffer) {
  if (!buffer || buffer.length === 0) {
    throw new Error('Invalid audio data: empty buffer');
  }

  if (buffer.numberOfChannels === 0) {
    throw new Error('Invalid audio data: no channels found');
  }

  // Log original audio specifications
  console.log('Audio specifications:', {
    sampleRate: buffer.sampleRate,
    numberOfChannels: buffer.numberOfChannels,
    length: buffer.length,
    duration: buffer.duration
  });
}