export interface AudioNodes {
  gainNode: GainNode;
  analyserNode: AnalyserNode;
  filterNode: BiquadFilterNode;
  sourceNode?: AudioBufferSourceNode;
  noiseNode?: AudioBufferSourceNode;
  noiseGainNode?: GainNode;
  noiseFilter?: BiquadFilterNode;
  compressor: DynamicsCompressorNode;
  echoNode?: DelayNode;
  echoGainNode?: GainNode;
  feedbackNode?: GainNode;
}

export interface AudioState {
  tempo: number;
  pitch: number;
  volume: number;
  frequency: number;
  noise: number;
  echo: number;
}

export interface ExportFormat {
  id: string;
  label: string;
  mimeType: string;
  extension: string;
  bitrate?: number;
}

export type {
  AudioBufferSourceNode,
  BiquadFilterNode,
  DelayNode,
  GainNode
} from 'standardized-audio-context';