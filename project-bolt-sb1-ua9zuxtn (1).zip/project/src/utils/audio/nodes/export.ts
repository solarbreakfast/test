import { AudioNodes, AudioState } from '../types';
import { createNoiseBuffer } from '../generators/noise';

export function setupExportNodes(context: AudioContext, state: AudioState): AudioNodes {
  // Create main nodes
  const gainNode = context.createGain();
  const analyserNode = context.createAnalyser();
  const filterNode = context.createBiquadFilter();
  const compressor = context.createDynamicsCompressor();

  // Create noise nodes
  const noiseBuffer = createNoiseBuffer(context);
  const noiseNode = context.createBufferSource();
  const noiseFilter = context.createBiquadFilter();
  const noiseGainNode = context.createGain();

  // Set up noise chain
  noiseNode.buffer = noiseBuffer;
  noiseNode.loop = true;
  noiseFilter.type = 'bandpass';
  noiseFilter.frequency.value = 1000;
  noiseFilter.Q.value = 0.5;
  
  // Set initial noise gain based on state
  const noiseValue = (state.noise / 100) * 0.15;
  noiseGainNode.gain.setValueAtTime(noiseValue, 0);

  // Create echo nodes
  const echoNode = context.createDelay(2.0);
  const echoGainNode = context.createGain();
  const feedbackNode = context.createGain();

  // Set up echo parameters
  const normalizedEcho = state.echo / 100;
  echoNode.delayTime.setValueAtTime(0.3 + (normalizedEcho * 0.4), 0);
  echoGainNode.gain.setValueAtTime(normalizedEcho * 0.75, 0);
  feedbackNode.gain.setValueAtTime(normalizedEcho * 0.5, 0);

  // Set up compressor
  compressor.threshold.setValueAtTime(-24, 0);
  compressor.knee.setValueAtTime(30, 0);
  compressor.ratio.setValueAtTime(12, 0);
  compressor.attack.setValueAtTime(0.003, 0);
  compressor.release.setValueAtTime(0.25, 0);

  // Set up filter
  filterNode.type = 'peaking';
  filterNode.frequency.setValueAtTime(state.frequency, 0);
  filterNode.Q.setValueAtTime(1.0, 0);

  // Set up gain
  const gainValue = Math.pow(state.volume / 100, 2);
  gainNode.gain.setValueAtTime(gainValue, 0);

  // Connect nodes
  gainNode.connect(filterNode);
  filterNode.connect(compressor);

  // Connect noise chain
  noiseNode.connect(noiseFilter);
  noiseFilter.connect(noiseGainNode);
  noiseGainNode.connect(compressor);
  noiseNode.start(0);

  // Connect echo if enabled
  if (state.echo > 0) {
    filterNode.connect(echoNode);
    echoNode.connect(echoGainNode);
    echoGainNode.connect(compressor);
    echoGainNode.connect(feedbackNode);
    feedbackNode.connect(echoNode);
  }

  // Final output path
  compressor.connect(analyserNode);
  analyserNode.connect(context.destination);

  return {
    gainNode,
    analyserNode,
    filterNode,
    noiseNode,
    noiseGainNode,
    noiseFilter,
    compressor,
    echoNode,
    echoGainNode,
    feedbackNode
  };
}