import { AudioNodes } from '../types';

export function setupNodeConnections(context: AudioContext, nodes: AudioNodes) {
  const {
    gainNode,
    analyserNode,
    filterNode,
    noiseNode,
    noiseGainNode,
    noiseFilter,
    compressor,
    echoNode,
    echoGainNode,
    feedbackNode
  } = nodes;

  // Main signal path
  gainNode.connect(filterNode);
  filterNode.connect(compressor);
  
  // Echo path
  if (echoNode && echoGainNode && feedbackNode) {
    filterNode.connect(echoNode);
    echoNode.connect(echoGainNode);
    echoGainNode.connect(compressor);
    
    // Feedback loop
    echoGainNode.connect(feedbackNode);
    feedbackNode.connect(echoNode);
  }

  // Noise path
  if (noiseNode && noiseFilter && noiseGainNode) {
    noiseNode.connect(noiseFilter);
    noiseFilter.connect(noiseGainNode);
    noiseGainNode.connect(compressor);
    noiseNode.start(0);
  }

  // Final output path
  compressor.connect(analyserNode);
  analyserNode.connect(context.destination);
}