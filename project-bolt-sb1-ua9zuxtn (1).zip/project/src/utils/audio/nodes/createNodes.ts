import { AudioNodes } from '../types';
import { createCompressor } from './compressor';
import { createNoiseNodes } from './noise';
import { createEchoNodes } from './echo';
import { setupNodeConnections } from './connections';
import { AUDIO_CONSTRAINTS } from '../../../constants/audio';

export function createAudioNodes(context: AudioContext): AudioNodes {
  const compressor = createCompressor(context);
  const gainNode = context.createGain();
  const analyserNode = context.createAnalyser();
  const filterNode = context.createBiquadFilter();
  const { noiseNode, noiseFilter, noiseGainNode } = createNoiseNodes(context);
  const { echoNode, echoGainNode, feedbackNode } = createEchoNodes(context);
  
  // Set initial node states
  gainNode.gain.value = 1.0;
  filterNode.type = 'lowpass';
  filterNode.frequency.value = AUDIO_CONSTRAINTS.frequency.default; // Initialize to minimum frequency
  filterNode.Q.value = 1.0;
  
  const nodes = {
    gainNode,
    analyserNode,
    filterNode,
    noiseNode,
    noiseGainNode,
    noiseFilter,
    compressor,
    echoNode,
    echoGainNode,
    feedbackNode
  };
  
  setupNodeConnections(context, nodes);
  
  return nodes;
}