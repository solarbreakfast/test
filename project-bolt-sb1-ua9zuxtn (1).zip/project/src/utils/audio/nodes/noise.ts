import { createNoiseBuffer } from '../generators/noise';

export function createNoiseNodes(context: AudioContext) {
  const noiseBuffer = createNoiseBuffer(context);
  const noiseNode = context.createBufferSource();
  const noiseFilter = context.createBiquadFilter();
  const noiseGainNode = context.createGain();
  
  noiseNode.buffer = noiseBuffer;
  noiseNode.loop = true;
  noiseFilter.type = 'bandpass';
  noiseFilter.frequency.value = 1000;
  noiseFilter.Q.value = 0.5;
  noiseGainNode.gain.value = 0;
  
  return { noiseNode, noiseFilter, noiseGainNode };
}