import { DelayNode, GainNode } from '../types';

export function applyEcho(
  delayNode: DelayNode,
  echoGainNode: GainNode,
  feedbackNode: GainNode,
  value: number
) {
  // Ensure value is finite and within bounds
  const normalizedValue = Math.max(0, Math.min(value / 100, 1)) || 0;
  
  // Set echo volume (0 to 0.75)
  const echoVolume = normalizedValue * 0.75;
  if (Number.isFinite(echoVolume)) {
    echoGainNode.gain.setTargetAtTime(echoVolume, echoGainNode.context.currentTime, 0.01);
  }
  
  // Set feedback amount (0 to 0.5)
  const feedbackAmount = normalizedValue * 0.5;
  if (Number.isFinite(feedbackAmount)) {
    feedbackNode.gain.setTargetAtTime(feedbackAmount, feedbackNode.context.currentTime, 0.01);
  }
  
  // Adjust delay time based on value (300ms to 700ms)
  const delayTime = 0.3 + (normalizedValue * 0.4);
  if (Number.isFinite(delayTime)) {
    delayNode.delayTime.setTargetAtTime(delayTime, delayNode.context.currentTime, 0.01);
  }
}