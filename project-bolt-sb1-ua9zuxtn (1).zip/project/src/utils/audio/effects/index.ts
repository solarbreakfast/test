export * from './echo';
export * from './noise';
export * from './volume';
export * from './frequency';
export * from './pitch';
export * from './tempo';

import { AudioNodes } from '../types';
import { applyEcho } from './echo';
import { applyNoise } from './noise';
import { applyVolume } from './volume';
import { applyFrequency } from './frequency';
import { applyPitch } from './pitch';
import { applyTempo } from './tempo';

export function applyAudioEffects(nodes: AudioNodes, param: string, value: number) {
  switch (param) {
    case 'tempo':
      if (nodes.sourceNode) {
        applyTempo(nodes.sourceNode, value);
      }
      break;
    case 'pitch':
      if (nodes.sourceNode) {
        applyPitch(nodes.sourceNode, value);
      }
      break;
    case 'frequency':
      applyFrequency(nodes.filterNode, value);
      break;
    case 'volume':
      applyVolume(nodes.gainNode, value);
      break;
    case 'noise':
      if (nodes.noiseGainNode) {
        applyNoise(nodes.noiseGainNode, value);
      }
      break;
    case 'echo':
      if (nodes.echoNode && nodes.echoGainNode && nodes.feedbackNode) {
        applyEcho(nodes.echoNode, nodes.echoGainNode, nodes.feedbackNode, value);
      }
      break;
  }
}