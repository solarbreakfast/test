import { AudioBufferSourceNode } from '../types';

export function applyTempo(sourceNode: AudioBufferSourceNode, value: number) {
  // Ensure value is within bounds and normalized
  const normalizedTempo = Math.max(0.5, Math.min(value, 2));
  
  // Apply tempo change with smooth transition
  if (sourceNode.playbackRate) {
    sourceNode.playbackRate.cancelScheduledValues(sourceNode.context.currentTime);
    sourceNode.playbackRate.setValueAtTime(sourceNode.playbackRate.value, sourceNode.context.currentTime);
    sourceNode.playbackRate.linearRampToValueAtTime(
      normalizedTempo,
      sourceNode.context.currentTime + 0.01
    );
  }
}