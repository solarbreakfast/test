import { AudioBufferSourceNode } from '../types';

export function applyPitch(sourceNode: AudioBufferSourceNode, semitones: number) {
  // Convert semitones to cents (100 cents = 1 semitone)
  const cents = Math.max(-1200, Math.min(semitones * 100, 1200));
  
  // Apply pitch change with smooth transition
  if (sourceNode.detune) {
    sourceNode.detune.cancelScheduledValues(sourceNode.context.currentTime);
    sourceNode.detune.setValueAtTime(sourceNode.detune.value, sourceNode.context.currentTime);
    sourceNode.detune.linearRampToValueAtTime(
      cents,
      sourceNode.context.currentTime + 0.01
    );
  }
}