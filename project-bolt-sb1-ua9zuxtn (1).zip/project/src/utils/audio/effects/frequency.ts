import { BiquadFilterNode } from '../types';
import { MUSICAL_FREQUENCIES } from '../../../constants/frequencies';

export function applyFrequency(filterNode: BiquadFilterNode, frequency: number) {
  // Logarithmic frequency scaling for more natural response
  const minFreq = 20;
  const maxFreq = 20000;
  const normalizedFreq = Math.exp(
    Math.log(minFreq) + (Math.log(maxFreq) - Math.log(minFreq)) * (frequency / maxFreq)
  );
  
  // Find nearest musical frequency for Q value adjustment
  const nearestNote = MUSICAL_FREQUENCIES.reduce((prev, curr) => {
    return Math.abs(curr.freq - frequency) < Math.abs(prev.freq - frequency) ? curr : prev;
  });

  // Enhanced Q value adjustment based on musical frequencies
  const proximity = Math.abs(frequency - nearestNote.freq) / frequency;
  const baseQ = 1.0;
  const resonanceQ = 2.5;
  const Q = baseQ + (1 - Math.min(proximity * 10, 1)) * (resonanceQ - baseQ);

  // Apply frequency with smooth transition
  filterNode.frequency.setTargetAtTime(
    Math.max(minFreq, Math.min(normalizedFreq, maxFreq)),
    filterNode.context.currentTime,
    0.01
  );

  // Apply Q value with smooth transition
  filterNode.Q.setTargetAtTime(Q, filterNode.context.currentTime, 0.01);

  // Adjust filter type based on frequency range
  if (frequency < 100) {
    filterNode.type = 'lowshelf';
  } else if (frequency > 10000) {
    filterNode.type = 'highshelf';
  } else {
    filterNode.type = 'peaking';
  }
}