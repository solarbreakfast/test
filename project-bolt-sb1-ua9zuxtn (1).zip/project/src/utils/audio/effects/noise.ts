import { GainNode } from '../types';

export function applyNoise(noiseGainNode: GainNode, value: number) {
  const normalizedValue = Math.max(0, Math.min(value / 100, 1));
  const logValue = normalizedValue === 0 ? 0 : Math.pow(normalizedValue, 2) * 0.15;
  noiseGainNode.gain.setTargetAtTime(logValue, noiseGainNode.context.currentTime, 0.01);
}