import { GainNode } from '../types';

export function applyVolume(gainNode: GainNode, value: number) {
  const minDb = -70;
  const maxDb = 12;
  const curve = 2;
  
  let volumeValue = Math.max(0, Math.min(value / 100, 3)); // Allow up to 300%
  
  if (volumeValue <= 0) {
    gainNode.gain.setTargetAtTime(0, gainNode.context.currentTime, 0.01);
  } else {
    volumeValue = Math.pow(volumeValue, 1/curve);
    const dbScale = minDb + (volumeValue * (maxDb - minDb));
    const gainValue = Math.pow(10, dbScale / 20);
    gainNode.gain.setTargetAtTime(gainValue, gainNode.context.currentTime, 0.01);
  }
}