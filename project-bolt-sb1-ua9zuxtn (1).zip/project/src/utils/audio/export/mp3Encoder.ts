import lamejs from 'lamejs';
import { ExportFormat, ExportQuality } from '../../../types/export';

export async function encodeToMp3(
  buffer: AudioBuffer,
  format: ExportFormat,
  quality: ExportQuality
): Promise<Blob> {
  // Configure MP3 encoder based on quality settings
  const channels = Math.min(buffer.numberOfChannels, 2); // Limit to stereo
  const sampleRate = quality.sampleRate;
  const kbps = getBitrateForQuality(format, quality);
  
  // Create MP3 encoder with optimized settings
  const mp3encoder = new lamejs.Mp3Encoder(
    channels,
    sampleRate,
    kbps
  );
  
  // Convert to mono/stereo samples with quality-appropriate processing
  const samples = convertToSamples(buffer, channels, quality);
  
  // Encode to MP3 with proper frame size and VBR settings
  const mp3Data = [];
  const sampleBlockSize = 1152; // MP3 standard frame size
  
  // Process samples in chunks with quality-specific optimizations
  for (let i = 0; i < samples[0].length; i += sampleBlockSize) {
    const leftChunk = samples[0].subarray(i, i + sampleBlockSize);
    const rightChunk = channels > 1 ? samples[1].subarray(i, i + sampleBlockSize) : leftChunk;
    
    // Handle last frame with proper padding
    if (leftChunk.length < sampleBlockSize) {
      const padSize = sampleBlockSize - leftChunk.length;
      const paddedLeft = new Int16Array(sampleBlockSize);
      const paddedRight = new Int16Array(sampleBlockSize);
      
      // Apply smooth padding for better audio transition
      paddedLeft.set(leftChunk);
      paddedRight.set(rightChunk);
      applyFadeOut(paddedLeft, leftChunk.length);
      applyFadeOut(paddedRight, rightChunk.length);
      
      const mp3buf = mp3encoder.encodeBuffer(paddedLeft, paddedRight);
      if (mp3buf.length > 0) {
        mp3Data.push(mp3buf);
      }
    } else {
      const mp3buf = mp3encoder.encodeBuffer(leftChunk, rightChunk);
      if (mp3buf.length > 0) {
        mp3Data.push(mp3buf);
      }
    }
  }
  
  // Flush encoder and add optimized ID3 tags
  const lastMp3buf = mp3encoder.flush();
  if (lastMp3buf.length > 0) {
    mp3Data.push(lastMp3buf);
  }

  // Add ID3v2 header with quality-specific metadata
  const id3v2 = createID3v2Header(quality);
  mp3Data.unshift(id3v2);
  
  // Combine all chunks into final MP3 blob with proper MIME type
  return new Blob(mp3Data, { 
    type: 'audio/mpeg'
  });
}

function getBitrateForQuality(format: ExportFormat, quality: ExportQuality): number {
  // Optimize bitrate based on quality setting
  switch (quality.id) {
    case 'high':
      return format.bitrate || 320;
    case 'medium':
      return Math.min(format.bitrate || 256, 256);
    case 'low':
      return Math.min(format.bitrate || 128, 128);
    default:
      return format.bitrate || 320;
  }
}

function convertToSamples(
  buffer: AudioBuffer, 
  channels: number,
  quality: ExportQuality
): Int16Array[] {
  const samples: Int16Array[] = [];
  const length = buffer.length;
  
  // Apply quality-specific processing
  const headroom = getHeadroomForQuality(quality);
  const ditherAmount = getDitherAmountForQuality(quality);
  
  // Convert each channel with optimized settings
  for (let channel = 0; channel < channels; channel++) {
    const channelData = buffer.getChannelData(channel);
    const channelSamples = new Int16Array(length);
    
    // Convert float32 to int16 with quality-appropriate processing
    for (let i = 0; i < length; i++) {
      // Apply quality-based dithering
      const dither = quality.id !== 'low' 
        ? (Math.random() * 2 - 1) * ditherAmount 
        : 0;
      
      // Scale to 16-bit range with quality-based headroom
      const sample = Math.max(-1, Math.min(1, channelData[i] * headroom + dither));
      channelSamples[i] = Math.round(sample * 0x7FFF);
    }
    
    samples.push(channelSamples);
  }
  
  return samples;
}

function getHeadroomForQuality(quality: ExportQuality): number {
  switch (quality.id) {
    case 'high':
      return 0.95; // Less headroom for higher quality
    case 'medium':
      return 0.92;
    case 'low':
      return 0.90; // More headroom for lower quality
    default:
      return 0.95;
  }
}

function getDitherAmountForQuality(quality: ExportQuality): number {
  switch (quality.id) {
    case 'high':
      return 0.5; // More subtle dithering for high quality
    case 'medium':
      return 0.75;
    case 'low':
      return 0; // No dithering for low quality
    default:
      return 0.5;
  }
}

function applyFadeOut(samples: Int16Array, startIndex: number): void {
  const fadeLength = Math.min(1152, samples.length - startIndex);
  for (let i = 0; i < fadeLength; i++) {
    const factor = 1 - (i / fadeLength);
    samples[startIndex + i] = Math.round(samples[startIndex + i] * factor);
  }
}

function createID3v2Header(quality: ExportQuality): Uint8Array {
  // Create ID3v2.3 tag with quality information
  const header = new Uint8Array(10);
  
  // ID3 marker
  header[0] = 0x49; // 'I'
  header[1] = 0x44; // 'D'
  header[2] = 0x33; // '3'
  
  // Version 2.3.0
  header[3] = 3;
  header[4] = 0;
  
  // No flags
  header[5] = 0;
  
  // Size (always 0 for minimal header)
  header[6] = 0;
  header[7] = 0;
  header[8] = 0;
  header[9] = 0;
  
  return header;
}