import { WavHeader, WavMetadata } from './types';

export function audioBufferToWav(buffer: AudioBuffer, metadata?: WavMetadata): ArrayBuffer {
  const format = 1; // PCM format
  const bitDepth = 16; // Standard CD quality
  const bytesPerSample = bitDepth / 8;
  const blockAlign = buffer.numberOfChannels * bytesPerSample;
  const byteRate = buffer.sampleRate * blockAlign;
  const dataSize = buffer.length * blockAlign;

  // Calculate total size including metadata chunks
  const metadataSize = metadata ? calculateMetadataSize(metadata) : 0;
  const headerSize = 44;
  const totalSize = headerSize + dataSize + metadataSize;

  const header: WavHeader = {
    totalSize: totalSize - 8,
    numberOfChannels: buffer.numberOfChannels,
    sampleRate: buffer.sampleRate,
    byteRate,
    blockAlign,
    bitDepth,
    dataSize
  };

  // Create WAV file with proper metadata
  const arrayBuffer = new ArrayBuffer(totalSize);
  const view = new DataView(arrayBuffer);
  let offset = 0;

  // RIFF chunk descriptor
  writeString(view, offset, 'RIFF'); offset += 4;
  view.setUint32(offset, header.totalSize, true); offset += 4;
  writeString(view, offset, 'WAVE'); offset += 4;

  // fmt sub-chunk
  writeString(view, offset, 'fmt '); offset += 4;
  view.setUint32(offset, 16, true); offset += 4; // Subchunk1Size (16 for PCM)
  view.setUint16(offset, format, true); offset += 2; // AudioFormat (1 for PCM)
  view.setUint16(offset, header.numberOfChannels, true); offset += 2;
  view.setUint32(offset, header.sampleRate, true); offset += 4;
  view.setUint32(offset, header.byteRate, true); offset += 4;
  view.setUint16(offset, header.blockAlign, true); offset += 2;
  view.setUint16(offset, header.bitDepth, true); offset += 2;

  // Write metadata chunks if provided
  if (metadata) {
    offset = writeMetadataChunks(view, offset, metadata);
  }

  // data sub-chunk
  writeString(view, offset, 'data'); offset += 4;
  view.setUint32(offset, header.dataSize, true); offset += 4;

  // Write audio data with proper interleaving and bit depth conversion
  const channels = Array.from({ length: buffer.numberOfChannels }, (_, i) => 
    buffer.getChannelData(i)
  );

  // Interleave channels and convert to 16-bit PCM
  for (let i = 0; i < buffer.length; i++) {
    for (let channel = 0; channel < buffer.numberOfChannels; channel++) {
      // Clamp samples between -1 and 1 and apply dithering
      const sample = Math.max(-1, Math.min(1, channels[channel][i]));
      const ditheredSample = applyDithering(sample);
      
      // Convert to 16-bit PCM with proper rounding
      const value = Math.round(ditheredSample < 0 ? ditheredSample * 0x8000 : ditheredSample * 0x7FFF);
      
      // Write sample as little-endian 16-bit
      view.setInt16(offset, value, true);
      offset += 2;
    }
  }

  return arrayBuffer;
}

function writeString(view: DataView, offset: number, string: string): void {
  for (let i = 0; i < string.length; i++) {
    view.setUint8(offset + i, string.charCodeAt(i));
  }
}

function calculateMetadataSize(metadata: WavMetadata): number {
  let size = 0;
  if (metadata.title) size += 8 + metadata.title.length;
  if (metadata.artist) size += 8 + metadata.artist.length;
  if (metadata.album) size += 8 + metadata.album.length;
  if (metadata.year) size += 8 + 4;
  return size;
}

function writeMetadataChunks(view: DataView, offset: number, metadata: WavMetadata): number {
  // Write LIST-INFO chunk
  if (metadata.title || metadata.artist || metadata.album || metadata.year) {
    writeString(view, offset, 'LIST'); offset += 4;
    const sizeOffset = offset;
    offset += 4; // Skip size field for now
    writeString(view, offset, 'INFO'); offset += 4;

    const startOffset = offset;

    if (metadata.title) {
      writeString(view, offset, 'INAM'); offset += 4;
      view.setUint32(offset, metadata.title.length, true); offset += 4;
      writeString(view, offset, metadata.title); offset += metadata.title.length;
    }

    if (metadata.artist) {
      writeString(view, offset, 'IART'); offset += 4;
      view.setUint32(offset, metadata.artist.length, true); offset += 4;
      writeString(view, offset, metadata.artist); offset += metadata.artist.length;
    }

    if (metadata.album) {
      writeString(view, offset, 'IPRD'); offset += 4;
      view.setUint32(offset, metadata.album.length, true); offset += 4;
      writeString(view, offset, metadata.album); offset += metadata.album.length;
    }

    if (metadata.year) {
      writeString(view, offset, 'ICRD'); offset += 4;
      view.setUint32(offset, 4, true); offset += 4;
      writeString(view, offset, metadata.year.toString()); offset += 4;
    }

    // Write chunk size
    view.setUint32(sizeOffset, offset - startOffset, true);
  }

  return offset;
}

function applyDithering(sample: number): number {
  // Apply triangular dithering
  const r = Math.random() + Math.random() - 1;
  return sample + (r * 0.5 / 32768);
}