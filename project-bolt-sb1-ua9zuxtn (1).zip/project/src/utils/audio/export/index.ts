import { AudioNodes, AudioState } from '../../../types/audio';
import { ExportFormat, ExportQuality } from '../../../types/export';
import { renderAudio } from './renderAudio';
import { audioBufferToWav } from './audioBufferToWav';
import { encodeToMp3 } from './mp3Encoder';

export async function exportProcessedAudio(
  audioContext: AudioContext,
  nodes: AudioNodes,
  audioBuffer: AudioBuffer,
  state: AudioState,
  format: ExportFormat,
  quality: ExportQuality,
  options = { includeEchoTail: true, normalizeOutput: true }
): Promise<Blob> {
  try {
    // Render audio with effects
    const renderedBuffer = await renderAudio(audioContext, nodes, audioBuffer, state, {
      includeEchoTail: options.includeEchoTail,
      normalizeOutput: options.normalizeOutput,
      fadeOutDuration: 0.1,
      targetSampleRate: quality.sampleRate
    });

    // Export based on format
    switch (format.id) {
      case 'mp3':
        return encodeToMp3(renderedBuffer, format, quality);
      
      case 'wav':
      default:
        const wavData = audioBufferToWav(renderedBuffer, {
          title: 'Processed Audio',
          artist: 'Audio Processor',
          year: new Date().getFullYear()
        });
        return new Blob([wavData], { type: format.mimeType });
    }
  } catch (error) {
    console.error('Error during audio export:', error);
    throw new Error('Failed to export audio');
  }
}

export * from './types';