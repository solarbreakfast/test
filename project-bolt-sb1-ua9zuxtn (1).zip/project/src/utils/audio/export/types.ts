export interface WavHeader {
  totalSize: number;
  numberOfChannels: number;
  sampleRate: number;
  byteRate: number;
  blockAlign: number;
  bitDepth: number;
  dataSize: number;
}

export interface WavMetadata {
  title?: string;
  artist?: string;
  album?: string;
  year?: number;
}

export interface ExportOptions {
  includeEchoTail?: boolean;
  normalizeOutput?: boolean;
  fadeOutDuration?: number;
  metadata?: WavMetadata;
}