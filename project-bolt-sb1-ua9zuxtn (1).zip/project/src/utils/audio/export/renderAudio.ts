import { AudioNodes, AudioState } from '../../../types/audio';
import { setupExportNodes } from '../nodes/export';
import { ExportOptions } from './types';

export async function renderAudio(
  audioContext: AudioContext,
  nodes: AudioNodes,
  audioBuffer: AudioBuffer,
  state: AudioState,
  options: ExportOptions = {}
): Promise<AudioBuffer> {
  const {
    includeEchoTail = true,
    normalizeOutput = true,
    fadeOutDuration = 0.1
  } = options;

  // Calculate export duration including echo tail if needed
  const echoTailDuration = includeEchoTail && state.echo > 0 ? 2.0 : 0;
  const exportDuration = audioBuffer.duration + echoTailDuration;
  
  // Create offline context with standard sample rate
  const offlineContext = new OfflineAudioContext(
    audioBuffer.numberOfChannels,
    Math.ceil(exportDuration * 44100), // Use standard CD quality sample rate
    44100 // Standard CD quality
  );

  // Set up nodes with current state
  const exportNodes = setupExportNodes(offlineContext, state);

  // Create and configure source node
  const sourceNode = offlineContext.createBufferSource();
  sourceNode.buffer = audioBuffer;
  sourceNode.playbackRate.value = state.tempo;
  sourceNode.detune.value = state.pitch * 100;
  sourceNode.connect(exportNodes.gainNode);

  // Add fade out to prevent clicks
  if (fadeOutDuration > 0) {
    const fadeOutStart = exportDuration - fadeOutDuration;
    exportNodes.gainNode.gain.setValueAtTime(exportNodes.gainNode.gain.value, fadeOutStart);
    exportNodes.gainNode.gain.linearRampToValueAtTime(0, exportDuration);
  }

  // Start rendering
  sourceNode.start(0);
  let renderedBuffer = await offlineContext.startRendering();

  // Normalize output if requested
  if (normalizeOutput) {
    renderedBuffer = await normalizeAudioBuffer(renderedBuffer);
  }

  return renderedBuffer;
}

async function normalizeAudioBuffer(buffer: AudioBuffer): Promise<AudioBuffer> {
  // Create a new context for processing
  const context = new OfflineAudioContext(
    buffer.numberOfChannels,
    buffer.length,
    44100 // Standard CD quality
  );

  // Find peak amplitude across all channels
  let maxAmp = 0;
  for (let channel = 0; channel < buffer.numberOfChannels; channel++) {
    const data = buffer.getChannelData(channel);
    const channelMax = Math.max(...data.map(Math.abs));
    maxAmp = Math.max(maxAmp, channelMax);
  }

  // Create source and gain nodes
  const source = context.createBufferSource();
  const gain = context.createGain();

  // Set normalization gain
  if (maxAmp > 0 && maxAmp !== 1) {
    const scalar = 0.99 / maxAmp; // Leave tiny headroom
    gain.gain.value = scalar;
  }

  // Connect and render
  source.buffer = buffer;
  source.connect(gain);
  gain.connect(context.destination);
  source.start(0);

  return context.startRendering();
}